import { env, json, githubRead, githubWrite, telegram, expiryFromDays } from "./_lib.js";

function constantTimeEqual(a, b) {
  if (typeof a !== "string" || typeof b !== "string" || a.length !== b.length) return false;
  let out = 0;
  for (let i = 0; i < a.length; i++) out |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return out === 0;
}

export default async function handler(req, res) {
  const secret = env("TELEGRAM_WEBHOOK_SECRET");

  if (req.method === "GET" && req.query?.setup === "1") {
    if (!constantTimeEqual(String(req.query.key || ""), secret)) return json(res, 403, { ok: false, message: "Forbidden" });
    const base = env("APP_BASE_URL").replace(/\/$/, "");
    const result = await telegram("setWebhook", {
      url: `${base}/api/telegram-webhook`,
      secret_token: secret,
      allowed_updates: ["callback_query"]
    });
    return json(res, 200, { ok: true, telegram: result.result });
  }

  if (req.method !== "POST") return json(res, 405, { ok: false, message: "Method tidak diizinkan." });
  const receivedSecret = req.headers["x-telegram-bot-api-secret-token"];
  if (!constantTimeEqual(receivedSecret, secret)) return json(res, 403, { ok: false, message: "Forbidden" });

  try {
    const update = req.body || {};
    const callback = update.callback_query;
    if (!callback?.data) return json(res, 200, { ok: true });

    const ownerId = String(env("TELEGRAM_OWNER_USER_ID"));
    if (String(callback.from?.id) !== ownerId) {
      await telegram("answerCallbackQuery", { callback_query_id: callback.id, text: "Hanya owner yang boleh melakukan aksi ini.", show_alert: true });
      return json(res, 200, { ok: true });
    }

    const [action, orderId] = callback.data.split(":");
    if (!["approve", "reject"].includes(action) || !orderId) {
      await telegram("answerCallbackQuery", { callback_query_id: callback.id, text: "Aksi tidak valid." });
      return json(res, 200, { ok: true });
    }

    const ordersPath = process.env.GITHUB_ORDERS_PATH || "pending-orders.json";
    const accountsPath = process.env.GITHUB_ACCOUNTS_PATH || "accounts.json";
    const ordersFile = await githubRead(ordersPath);
    const db = ordersFile.data;
    const order = db?.orders?.find(item => item.id === orderId);
    if (!order) {
      await telegram("answerCallbackQuery", { callback_query_id: callback.id, text: "Order tidak ditemukan.", show_alert: true });
      return json(res, 200, { ok: true });
    }
    if (order.status !== "pending") {
      await telegram("answerCallbackQuery", { callback_query_id: callback.id, text: `Order sudah ${order.status}.`, show_alert: true });
      return json(res, 200, { ok: true });
    }

    if (action === "approve") {
      const accountsFile = await githubRead(accountsPath);
      const accountsDb = accountsFile.data && Array.isArray(accountsFile.data.accounts)
        ? accountsFile.data
        : { status: true, version: 1, accounts: [] };

      const duplicate = accountsDb.accounts.some(a => String(a.username).toLowerCase() === order.username.toLowerCase());
      if (duplicate) {
        await telegram("answerCallbackQuery", { callback_query_id: callback.id, text: "Username sudah terdaftar.", show_alert: true });
        return json(res, 200, { ok: true });
      }

      const account = {
        id: order.id,
        username: order.username,
        password: order.password,
        role: order.role,
        telegramId: order.telegramId,
        expiredDate: expiryFromDays(order.days),
        createdAt: new Date().toISOString(),
        status: "active"
      };
      accountsDb.accounts.push(account);
      await githubWrite(accountsPath, accountsDb, accountsFile.sha, `Approve account ${order.username}`);

      order.status = "approved";
      order.processedAt = new Date().toISOString();
      order.processedBy = ownerId;
      await githubWrite(ordersPath, db, ordersFile.sha, `Mark order ${orderId} approved`);
      await telegram("answerCallbackQuery", { callback_query_id: callback.id, text: "Order disetujui." });
      await telegram("editMessageCaption", {
        chat_id: callback.message.chat.id,
        message_id: callback.message.message_id,
        caption: (callback.message.caption || callback.message.text || "") + "\n\n✅ DISETUJUI — akun ditambahkan ke accounts.json",
        reply_markup: { inline_keyboard: [] }
      }).catch(async () => {
        await telegram("editMessageText", {
          chat_id: callback.message.chat.id,
          message_id: callback.message.message_id,
          text: (callback.message.text || "Order") + "\n\n✅ DISETUJUI — akun ditambahkan ke accounts.json",
          reply_markup: { inline_keyboard: [] }
        });
      });
    } else {
      order.status = "rejected";
      order.processedAt = new Date().toISOString();
      order.processedBy = ownerId;
      await githubWrite(ordersPath, db, ordersFile.sha, `Reject order ${orderId}`);
      await telegram("answerCallbackQuery", { callback_query_id: callback.id, text: "Order ditolak." });
      await telegram("editMessageCaption", {
        chat_id: callback.message.chat.id,
        message_id: callback.message.message_id,
        caption: (callback.message.caption || callback.message.text || "") + "\n\n❌ DITOLAK",
        reply_markup: { inline_keyboard: [] }
      }).catch(async () => {
        await telegram("editMessageText", {
          chat_id: callback.message.chat.id,
          message_id: callback.message.message_id,
          text: (callback.message.text || "Order") + "\n\n❌ DITOLAK",
          reply_markup: { inline_keyboard: [] }
        });
      });
    }
    return json(res, 200, { ok: true });
  } catch (error) {
    console.error("webhook error", error);
    return json(res, 500, { ok: false, message: error.message || "Webhook error" });
  }
}
