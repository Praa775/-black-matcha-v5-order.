import { env, json, githubRead, githubWrite, telegram, getPackage, makeId } from "./_lib.js";

export const config = { api: { bodyParser: false } };

async function readMultipart(req) {
  const chunks = [];
  let size = 0;
  for await (const chunk of req) {
    size += chunk.length;
    if (size > 4 * 1024 * 1024) throw new Error("Total upload terlalu besar (maksimum 4 MB).");
    chunks.push(chunk);
  }
  const raw = Buffer.concat(chunks);
  const contentType = req.headers["content-type"] || "";
  const boundaryMatch = contentType.match(/boundary=(?:"([^"]+)"|([^;]+))/i);
  if (!boundaryMatch) throw new Error("Format form tidak valid.");
  const boundary = boundaryMatch[1] || boundaryMatch[2];
  const parts = raw.toString("latin1").split(`--${boundary}`);
  const fields = {};
  let proof = null;

  for (const part of parts) {
    const splitAt = part.indexOf("\r\n\r\n");
    if (splitAt < 0) continue;
    const headers = part.slice(0, splitAt);
    let body = part.slice(splitAt + 4);
    body = body.replace(/\r\n$/, "").replace(/\r\n--$/, "");
    const disposition = headers.match(/content-disposition:\s*form-data;\s*name="([^"]+)"(?:;\s*filename="([^"]*)")?/i);
    if (!disposition) continue;
    const name = disposition[1];
    const filename = disposition[2];
    if (filename !== undefined) {
      if (!filename) continue;
      const mime = (headers.match(/content-type:\s*([^\r\n]+)/i) || [])[1] || "";
      const buffer = Buffer.from(body, "latin1");
      proof = { filename, mime: mime.trim().toLowerCase(), buffer };
    } else {
      fields[name] = Buffer.from(body, "latin1").toString("utf8").trim();
    }
  }
  return { fields, proof };
}

export default async function handler(req, res) {
  if (req.method !== "POST") return json(res, 405, { ok: false, message: "Method tidak diizinkan." });
  try {
    // Fail early when deployment configuration is incomplete.
    env("TELEGRAM_BOT_TOKEN");
    env("TELEGRAM_OWNER_CHAT_ID");
    const { fields, proof } = await readMultipart(req);
    const pack = getPackage(fields.packageId);
    const username = fields.username || "";
    const password = fields.password || "";
    const telegramId = fields.telegramId || "";

    if (!pack) return json(res, 400, { ok: false, message: "Paket tidak valid." });
    if (!/^[a-zA-Z0-9_.-]{3,32}$/.test(username)) return json(res, 400, { ok: false, message: "Username 3–32 karakter; gunakan huruf, angka, titik, garis bawah, atau strip." });
    if (password.length < 6 || password.length > 72) return json(res, 400, { ok: false, message: "Password harus 6–72 karakter." });
    if (!/^\d{5,20}$/.test(telegramId)) return json(res, 400, { ok: false, message: "Telegram ID harus berupa angka." });
    if (pack.price > 0 && !proof) return json(res, 400, { ok: false, message: "Bukti transfer wajib diunggah." });
    if (proof && (!["image/jpeg", "image/png", "image/webp"].includes(proof.mime) || proof.buffer.length > 3 * 1024 * 1024)) {
      return json(res, 400, { ok: false, message: "Bukti harus JPG, PNG, atau WEBP dan maksimal 3 MB." });
    }

    const id = makeId();
    const order = {
      id, packageId: fields.packageId, packageLabel: pack.label, role: pack.role,
      price: pack.price, days: pack.days, username, password, telegramId,
      status: "pending", createdAt: new Date().toISOString()
    };

    const ordersPath = process.env.GITHUB_ORDERS_PATH || "pending-orders.json";
    const current = await githubRead(ordersPath);
    const db = current.data && Array.isArray(current.data.orders) ? current.data : { version: 1, orders: [] };
    db.orders.push(order);
    await githubWrite(ordersPath, db, current.sha, `New order ${id}`);

    const caption = [
      `🧾 ORDER BLACK MATCHA V5`,
      `ID: ${id}`,
      `Paket: ${pack.label}`,
      `Harga: ${pack.price === 0 ? "GRATIS" : `Rp${pack.price.toLocaleString("id-ID")}`}`,
      `Username: ${username}`,
      `Telegram ID: ${telegramId}`,
      `Status: MENUNGGU PERSETUJUAN`,
      ``,
      `Periksa bukti dan pembayaran sebelum menyetujui.`
    ].join("\n");

    const keyboard = {
      inline_keyboard: [[
        { text: "✅ SETUJUI", callback_data: `approve:${id}` },
        { text: "❌ TOLAK", callback_data: `reject:${id}` }
      ]]
    };

    if (proof) {
      const token = env("TELEGRAM_BOT_TOKEN");
      const form = new FormData();
      form.append("chat_id", env("TELEGRAM_OWNER_CHAT_ID"));
      form.append("caption", caption);
      form.append("reply_markup", JSON.stringify(keyboard));
      form.append("photo", new Blob([proof.buffer], { type: proof.mime }), proof.filename || "proof");
      const sent = await fetch(`https://api.telegram.org/bot${token}/sendPhoto`, { method: "POST", body: form });
      const sentJson = await sent.json();
      if (!sent.ok || !sentJson.ok) throw new Error(`Telegram sendPhoto gagal: ${JSON.stringify(sentJson)}`);
    } else {
      await telegram("sendMessage", { chat_id: env("TELEGRAM_OWNER_CHAT_ID"), text: caption, reply_markup: keyboard });
    }

    return json(res, 200, { ok: true, orderId: id, message: "Order terkirim. Tunggu konfirmasi owner melalui Telegram." });
  } catch (error) {
    console.error("order error", error);
    return json(res, 500, { ok: false, message: error.message || "Terjadi kesalahan server." });
  }
}
