const GH_API = "https://api.github.com";

export function env(name) {
  const value = process.env[name];
  if (!value) throw new Error(`Environment variable ${name} belum diatur`);
  return value;
}

export function json(res, status, data) {
  res.status(status).setHeader("Content-Type", "application/json; charset=utf-8");
  res.end(JSON.stringify(data));
}

export async function githubRead(path) {
  const owner = env("GITHUB_OWNER");
  const repo = env("GITHUB_REPO");
  const branch = process.env.GITHUB_BRANCH || "main";
  const token = env("GITHUB_TOKEN");
  const url = `${GH_API}/repos/${owner}/${repo}/contents/${encodeURIComponent(path).replaceAll("%2F", "/")}?ref=${encodeURIComponent(branch)}`;
  const response = await fetch(url, {
    headers: {
      Authorization: `Bearer ${token}`,
      Accept: "application/vnd.github+json",
      "X-GitHub-Api-Version": "2022-11-28"
    }
  });
  if (response.status === 404) return { data: null, sha: null };
  if (!response.ok) throw new Error(`GitHub read gagal (${response.status}): ${await response.text()}`);
  const item = await response.json();
  const decoded = Buffer.from(item.content.replace(/\n/g, ""), "base64").toString("utf8");
  return { data: JSON.parse(decoded), sha: item.sha };
}

export async function githubWrite(path, data, sha, message) {
  const owner = env("GITHUB_OWNER");
  const repo = env("GITHUB_REPO");
  const branch = process.env.GITHUB_BRANCH || "main";
  const token = env("GITHUB_TOKEN");
  const url = `${GH_API}/repos/${owner}/${repo}/contents/${encodeURIComponent(path).replaceAll("%2F", "/")}`;
  const body = {
    message,
    content: Buffer.from(JSON.stringify(data, null, 2) + "\n").toString("base64"),
    branch
  };
  if (sha) body.sha = sha;
  const response = await fetch(url, {
    method: "PUT",
    headers: {
      Authorization: `Bearer ${token}`,
      Accept: "application/vnd.github+json",
      "X-GitHub-Api-Version": "2022-11-28",
      "Content-Type": "application/json"
    },
    body: JSON.stringify(body)
  });
  if (!response.ok) throw new Error(`GitHub write gagal (${response.status}): ${await response.text()}`);
  return response.json();
}

export async function telegram(method, payload) {
  const token = env("TELEGRAM_BOT_TOKEN");
  const response = await fetch(`https://api.telegram.org/bot${token}/${method}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload)
  });
  const result = await response.json();
  if (!response.ok || !result.ok) throw new Error(`Telegram ${method} gagal: ${JSON.stringify(result)}`);
  return result;
}

export function getPackage(packageId) {
  const packages = {
    day1: { label: "1 Hari", role: "member", price: 2000, days: 1 },
    day7: { label: "7 Hari", role: "member", price: 10000, days: 7 },
    month1: { label: "1 Bulan", role: "member", price: 25000, days: 30 },
    member: { label: "Member Forever", role: "member", price: 40000, days: null },
    reseller: { label: "Reseller Forever", role: "reseller", price: 75000, days: null },
    admin: { label: "Admin Forever", role: "admin", price: 100000, days: null },
    partner: { label: "Partner Forever", role: "partner", price: 150000, days: null },
    moderator: { label: "Moderator Forever", role: "moderator", price: 200000, days: null },
    owner: { label: "Owner Forever", role: "owner", price: 250000, days: null },
    creator: { label: "Creator", role: "creator", price: 0, days: null }
  };
  return packages[packageId] || null;
}

export function makeId() {
  return `BMV5-${Date.now().toString(36).toUpperCase()}-${crypto.randomUUID().slice(0, 6).toUpperCase()}`;
}

export function expiryFromDays(days) {
  if (!days) return null;
  const date = new Date();
  date.setUTCDate(date.getUTCDate() + days);
  return date.toISOString();
}
