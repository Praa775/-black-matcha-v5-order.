# BLACK MATCHA V5 — Auto Order (Vercel + GitHub + Telegram)

Project ini berisi website order dan backend serverless Vercel. Pembayaran QRIS **diverifikasi manual oleh owner** melalui tombol Setujui/Tolak di Telegram. Sistem ini tidak membaca status pembayaran langsung dari QRIS.

## Fitur
- Website responsif tema matcha.
- Paket: 1 hari, 7 hari, 1 bulan, Member, Reseller, Admin, Partner, Moderator, Owner, Creator gratis.
- Tidak ada paket VIP.
- Form username, password, Telegram ID, dan bukti transfer.
- Order disimpan ke `pending-orders.json` di GitHub.
- Bot Telegram mengirim bukti order dengan tombol Setujui/Tolak.
- Saat disetujui, data akun ditambahkan ke `accounts.json` di GitHub.

## Deploy
1. Upload isi folder project ini ke repository GitHub **private**.
2. Import repository ke Vercel.
3. Tambahkan Environment Variables di Vercel sesuai `.env.example`.
4. Pastikan `GITHUB_TOKEN` memiliki izin **Contents: Read and write** untuk repository.
5. Pastikan file `accounts.json` ada di root repo. Format awal:
   ```json
   {
     "status": true,
     "version": 1,
     "accounts": []
   }
   ```
6. Deploy project di Vercel.
7. Di Telegram, buka bot lalu tekan `/start`. Pastikan `TELEGRAM_OWNER_CHAT_ID` benar.
8. Pasang webhook Telegram dengan membuka URL berikut sekali di browser:
   `https://API_BASE/api/telegram-webhook?setup=1&key=TELEGRAM_WEBHOOK_SECRET`
   Ganti `API_BASE` dengan URL deployment dan `TELEGRAM_WEBHOOK_SECRET` dengan secret yang sama persis. Jangan bagikan URL ini.
9. Coba order nominal kecil untuk tes.

## Environment variables wajib
- `TELEGRAM_BOT_TOKEN`
- `TELEGRAM_OWNER_USER_ID`
- `TELEGRAM_OWNER_CHAT_ID`
- `TELEGRAM_WEBHOOK_SECRET`
- `GITHUB_TOKEN`
- `GITHUB_OWNER`
- `GITHUB_REPO`
- `GITHUB_BRANCH`
- `APP_BASE_URL`

## Catatan penting keamanan
- Repository GitHub harus **private** karena file order berisi data pelanggan.
- Jangan pernah memasukkan token Telegram/GitHub ke file frontend atau mengirimkannya ke orang lain.
- Demi kompatibilitas dengan aplikasi lama, contoh ini menyimpan password sesuai input pelanggan ke `accounts.json`. Ini berarti password tersimpan sebagai teks biasa. Untuk penggunaan publik, sebaiknya ubah aplikasi login agar memakai password hash (bcrypt/argon2) dan sesuaikan proses autentikasinya.
- Batasi akses repo dan environment variables. Hapus order lama secara berkala sesuai kebijakan privasi.
- Upload bukti dibatasi 3 MB dan format JPG, PNG, atau WEBP.
- Telegram Bot API memiliki batas ukuran media; gunakan bukti yang tidak terlalu besar.
- Untuk mencegah order palsu, owner wajib memeriksa nominal, waktu, dan tujuan pembayaran sebelum menekan Setujui.

## Catatan integrasi accounts.json
Format akun yang ditulis backend:
```json
{
  "id": "BMV5-...",
  "username": "username",
  "password": "password-dari-form",
  "role": "member",
  "telegramId": "123456789",
  "expiredDate": "2026-12-08T00:00:00.000Z",
  "createdAt": "2026-11-08T00:00:00.000Z",
  "status": "active"
}
```
Tanggal kedaluwarsa dihitung dari waktu persetujuan. Untuk role permanen nilainya `null`. Jika parser APK menggunakan nama field/format berbeda, sesuaikan sebelum digunakan live.

## Endpoint
- `POST /api/order` — menerima order multipart/form-data.
- `POST /api/telegram-webhook` — menerima callback tombol Telegram.
- `GET /api/telegram-webhook?setup=1&key=...` — memasang webhook.

## Development lokal
Install Vercel CLI, jalankan `vercel dev`, lalu isi environment variables lokal di `.env` (jangan commit file `.env`).
